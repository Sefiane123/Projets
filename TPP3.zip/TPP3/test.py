import sqlite3
print("Hello world")
